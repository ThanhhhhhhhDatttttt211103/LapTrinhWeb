﻿using BTLWeb.Models;

namespace BTLWeb.Repository
{
    public interface IChiTietHDBRepository : IRepository<TChiTietHdb>
    {
    }
}
