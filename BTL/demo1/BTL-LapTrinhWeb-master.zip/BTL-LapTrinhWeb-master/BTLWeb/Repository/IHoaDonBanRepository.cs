﻿using BTLWeb.Models;

namespace BTLWeb.Repository
{
    public interface IHoaDonBanRepository : IRepository<THoaDonBan>
    {

    }
}
