﻿using BTLWeb.Models;
namespace BTLWeb.ViewModels
{
	public class HomeProductDetailViewModels
	{
		public TDanhMucSp danhMucSp { get; set; }
		public List<TAnhSp> anhSps { get; set; }
	}
}
