﻿namespace BTLWeb.Models.ViewModels
{
    public class OrderDetailViewModel
    {
        public int MaHoaDon { set; get; }

        public int MaSP { set; get; }

        public int SoLuongBan { set; get; }
    }
}
